
var roleUpgrader = {

    run: function(creep, my_spawns, sources) {
        // --starter logic start--
        
        creep.say("🔋");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        var sources = creep.room.find(FIND_SOURCES);
        
        if (!creep.memory.full) {
            if (creep.harvest(sources[0]) == ERR_NOT_IN_RANGE) {
                creep.moveTo(sources[0]);
            }
        } else if (creep.memory.full) {
            // console.log(my_spawns[0].store["energy"], my_spawns[0].store.getCapacity());
            var controller = creep.room.controller;
            if (controller.level < 3 || controller.ticksToDowngrade < 10000) {
                if (creep.upgradeController(controller) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(controller);
                }
            }
        }
        // --starter logic end--
        
    }
};

module.exports = roleUpgrader;