var starter_max = [], miner_max = [], carryer_max = [], upgrader_max = [],
    my_spawns = [], sources = [], spawner = [],
    extensions_mass = [], ext_count = [], spawning_lvl = [],
    
    starter_count = [],
    upgrader_count = [],
    miner_count = [],
    carryer_max = [],

    funcs = require("funcs"),
    roleMiner = require("miner"),
    roleUpgrader = require("upgrader"),
    roleStarter = require("starter");
    
    my_rooms = ["W8N7"];
    
function which_room(start_room) {
    var r;
    for (var i = 0; i < my_rooms.length; i++) {
        if (start_room == my_rooms[i]) {
            r = i;
            break;
        }
    }
    return r;
}


function spawn_start (spawner, i) {
    if (starter_count[i] < starter_max[i]) {
        funcs.spawn_creep("Starter", starter_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (miner_count[i] < miner_max[i]) {
        funcs.spawn_creep("Miner", miner_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (upgrader_count[i] < upgrader_max[i]) {
        funcs.spawn_creep("Upgrader", upgrader_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    }
} 

module.exports.loop = function () {
    
    for (var i = 0; i < my_rooms.length; i++) { // проход по румам
        starter_count[i] = 0,
        miner_count[i] = 0,
        upgrader_count[i] = 0,
        miner_count[i] = 0,
        // carryer_count[i] = 0,
        
        starter_max[i] = 1,
        miner_max[i] = 1,
        upgrader_max[i] = 1;
        
        if (Game.rooms[my_rooms[i]].controller.level == 1) {
            miner_max = 0;
            carryer_max = 0;
        }
        
        my_spawns[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_SPAWN}})
        my_spawns[i].sort((a,b) => a.store[RESOURCE_ENERGY] - b.store[RESOURCE_ENERGY]);
        if (my_spawns[i].length > 1) {
            if (my_spawns[i][0].spawning) {
                spawner[i] = my_spawns[i][1];
            } else { spawner[i] = my_spawns[i][0]; }
        } else { spawner[i] = my_spawns[i][0]; }
        
        extensions_mass[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_EXTENSION}});
        extensions_mass[i].sort((a,b) => a.energy - b.energy);
        ext_count[i] = extensions_mass[i].length;
        
        if (ext_count[i] <= 4) {
            spawning_lvl[i] = 1;
        } else if (5 <= ext_count && ext_count <= 9) {
            spawning_lvl[i] = 2;
        } else if (10 <= ext_count && ext_count <= 19) {
            spawning_lvl[i] = 3;
        } else if (20 <= ext_count && ext_count <= 29) {
            spawning_lvl[i] = 4;
        } else if (30 <= ext_count && ext_count <= 49) {
            spawning_lvl[i] = 5;
        } else if (50 >= ext_count) {
            spawning_lvl[i] = 6;
        }
        
        
        sources[i] = Game.rooms[my_rooms[i]].find(FIND_SOURCES);
        console.log(sources[i][0].pos, sources[i][1].pos);    
    }
    
    
    for (var name in Game.creeps) { // проход по крипам
        var creep = Game.creeps[name];
        const r = which_room(creep.memory.start_room);
        
        
        if (creep.memory.role == "Starter") {
            starter_count[r]++;
            roleStarter.run(creep, my_spawns[r], sources[r]);
        } else if (creep.memory.role == "Miner") {
            miner_count[r]++;
            roleMiner.run(creep, my_spawns[r], sources[r]);
        } else if (creep.memory.role == "Upgrader") {
            upgrader_count[r]++;
            roleUpgrader.run(creep, my_spawns[r]);
        }
    }
     
    // console.log(upgrader_count[i], upgrader_max[i]);
    
    for (var i = 0; i < my_rooms.length; i++) { // 2-й проход по румам
        if (!spawner[i].spawning) {
            switch (spawning_lvl[i]) {
                case 1:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 300) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 2:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 550) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 3:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 800) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 4:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 1300) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 5:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 1800) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 6:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 5000) {
                        spawn_start(spawner, i);
                    }
                    break;
            }
        }
    
        
        
    }
    
    
    
    
     
}