var dest_mining;

var roleMiner = {

    run: function(creep, my_spawns, sources) {
        // --starter logic start--
        
        creep.say("⛏");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        if (creep.name.split('Miner')[1] <= 1) {
            dest_mining = 0;
        } else if (creep.name.split('Miner')[1] <= 2) {
            dest_mining = 1;
        }
        
        if (!creep.memory.full) {
            if (creep.harvest(sources[dest_mining]) == ERR_NOT_IN_RANGE) {
                creep.moveTo(sources[dest_mining]);
            }
        } else if (creep.memory.full) {
            const near_container= creep.pos.findInRange(FIND_STRUCTURES, 1, {
                filter: (i) => i.structureType == STRUCTURE_CONTAINER &&
                               i.store[RESOURCE_ENERGY] < 2000
            });
            
            const building = creep.pos.findInRange(FIND_CONSTRUCTION_SITES, 3)[0];
            
            if (building) {
                creep.build(building);
            }
        }
        
        // --starter logic end--
        
    }
};

module.exports = roleMiner;