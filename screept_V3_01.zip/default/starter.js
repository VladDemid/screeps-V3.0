
var roleStarter = {

    run: function(creep, my_spawns, sources) {
        // --starter logic start--
        
        creep.say("⛽️");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        if (!creep.memory.full) {
            if (creep.harvest(sources[0]) == ERR_NOT_IN_RANGE) {
                creep.moveTo(sources[0]);
            }
        } else if (creep.memory.full) {
            // console.log(my_spawns[0].store["energy"], my_spawns[0].store.getCapacity());
            if (my_spawns[0].store["energy"] < 300) {
                console.log("spawn low energy");
                if(creep.transfer(my_spawns[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_spawns[0]);
                }
            } else {
                if (!creep.pos.isNearTo(my_spawns[0])) {
                    creep.moveTo(my_spawns[0]);
                }
            }
        }
        // --starter logic end--
        
    }
};

module.exports = roleStarter;