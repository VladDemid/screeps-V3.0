module.exports.bring_smth = function bring_smth(creep, from, resourse, to, ammount) { // нести до ammount
    const need_res = ammount - to.store[resourse];
    var now_take;
          
    if (need_res > creep.store.getCapacity()) {
        now_take = creep.store.getCapacity();
    } else {
        now_take = need_res;
    }
    
    if (need_res > 0) { // проверка на необходимость
        if (from.store[resourse] > 0 || creep.store[resourse] > 0) { // проверка на наличие
            
            if (creep.store.getFreeCapacity() == 0  || creep.store[resourse] == need_res) {
                creep.memory.full = true;
            } else if (creep.store.getFreeCapacity() == creep.store.getCapacity()) {
                creep.memory.full = false;
            }
            
            if (!creep.memory.full) {
                creep.say("🧪📥");
                // console.log("found 🧪", resourse, "take ", now_take, "need", need_res);
                if(creep.withdraw(from, resourse, now_take) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(from);
                }
            } else if (creep.memory.full) {
                creep.say("🧪📤");
                if(creep.transfer(to, resourse) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(to);
                }
            }
            
        } else {
            creep.say("🧪❌");
            console.log("in ", from.pos, " no ", resourse);
        }
    } else {
        creep.say("🧪⏱");
        console.log("transfer finished ", resourse, " in ", to.pos);
    }
    
}



module.exports.take_from_to = function take_from_to(creep, res, from, to) {
    var alive = true;
    if (creep.ticksToLive < 30) {
        alive = false;
    }
    if (alive) {
        if (to.store.getFreeCapacity() > creep.store.getCapacity() ){
            if (creep.store.getFreeCapacity() == creep.store.getCapacity() && from.store[res] > 0) {
                if(creep.withdraw(from, res) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(from);
                }
            } else if (creep.store[res] > 0) {
                if(creep.transfer(to, res) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(to);
                }
            }
        }   
    } else if (creep.store[res] > 0) {
        if(creep.transfer(from, res) == ERR_NOT_IN_RANGE) {
            creep.moveTo(from);
        }
    } else {
        creep.suicide();
    }
}


module.exports.make_reaction = function make_reaction(creep, labs, res0, res1, res2, ammount, my_terminal) {
    var alive = true,
        ress = [res0, res1, res2]
    if (creep.ticksToLive < 30) {
        alive = false;
    }
    // if (labs[2].store[res2] < ammount && labs[0].store[res0] > 0 && labs[1].store[res1] > 0 && alive) {
    if (alive) {
        if ( (labs[0].store[res0] < ammount || labs[1].store[res1] < ammount) && labs[2].store[res2] == 0 && creep.store[res2] == 0) {
            if (labs[0].store[res0] < ammount) {
                this.bring_smth(creep, my_terminal, res0, labs[0], ammount)
            } else if (labs[1].store[res1] < ammount) {
                this.bring_smth(creep, my_terminal, res1, labs[1], ammount)
            }
        } else if (labs[0].store[res0] > 0 && labs[1].store[res1] > 0 ){
            // console.log("resourses ready, start reaction");
            creep.say("⚗️");
            // creep.moveTo(labs[2]);
            if (labs[2].cooldown == 0) {
                labs[2].runReaction(labs[0], labs[1]);
            }
        } else if (labs[2].store[res2] > 0 || creep.store[res2] > 0 ) {
            creep.say("🧪📦");
            if (creep.store[res2] == 0 && labs[2].store[res2] > 0) {
                if(creep.withdraw(labs[2], res2) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(labs[2]);
                }
            } else if (creep.store[res2] > 0) {
                if(creep.transfer(my_terminal, res2) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_terminal);
                }
            }
        }
    // } 
    } else if (creep.store.getFreeCapacity() != creep.store.getCapacity()) {
        for (var i = 0; i < ress.length; i++) {
            if (creep.store[ress[i]] > 0) {
                if(creep.transfer(my_terminal, ress[i]) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_terminal);
                }
            }
        }
    } else {
        creep.suicide();
    }
}