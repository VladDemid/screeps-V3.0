
var roleHelper = {

    run: function(creep, my_spawns, sources, extensions_mass, towers_mass, containers_mass, my_storage) {
        // --helper logic start--
        
        creep.say("🧰");
        if (creep.store["energy"] < 50) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        // console.log(sources[0].pos);
        if (!creep.memory.full) {
            if (my_storage && my_storage.store["energy"] > 0) {
                if(creep.withdraw(my_storage, "energy") == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_storage)) {
                        creep.moveTo(my_storage);
                    } 
                }
            } else {
                const near_container = creep.pos.findInRange(FIND_STRUCTURES, 3, {filter: {structureType: STRUCTURE_CONTAINER}})[0];
                if (near_container && near_container.store["energy"] > 0) {
                    if(creep.withdraw(near_container, "energy") == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(near_container)) {
                            creep.moveTo(near_container);
                        } 
                    }
                } else {
                    const my_container = containers_mass[containers_mass.length - 1]
                    if (my_container && my_container.store["energy"] > 0) {
                        if(creep.withdraw(my_container, "energy") == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(my_container)) {
                                creep.moveTo(my_container);
                            } 
                        }
                    }
                }
                
            }
            
            
            if (creep.carry.energy > 50) { //если одновременно новый спавн и "creep.memory.have_energy = false" то по пути на склад заполнять ext
                const range_1_ext = creep.pos.findInRange(FIND_STRUCTURES, 1, {
                    filter: (i) => i.structureType == STRUCTURE_EXTENSION &&
                                      i.store[RESOURCE_ENERGY] < i.store.energyCapacity
                    }); 
                if  (range_1_ext && range_1_ext.length > 0) {
                    creep.transfer(range_1_ext[0], RESOURCE_ENERGY);
                }
            }
        } else if (creep.memory.full) {
            // console.log(my_spawns[0].store["energy"], my_spawns[0].store.getCapacity());
            if (my_spawns[0].store["energy"] < 300) {
                if(creep.transfer(my_spawns[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_spawns[0]);
                }
            } else if (extensions_mass[0] && extensions_mass[0].store.getFreeCapacity("energy") > 0) {
                const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                if  (range_1_str) {
                    for (var y = 0; y < range_1_str.length;y++) {
                        if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                            creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                            creep.moveTo(extensions_mass[0]); //move к самому незаполненному (потому что можно)
                        }
                    }
                } else if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extensions_mass[0]);
                }
                if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(extensions_mass[0]);
                }
            } else if (towers_mass.length && towers_mass[0].store["energy"] < 800) {
                if(creep.transfer(towers_mass[0], "energy") == ERR_NOT_IN_RANGE) {
                    creep.moveTo(towers_mass[0]);
                }
            } else if (creep.store.getFreeCapacity() > 0) {
                creep.memory.full = false;
            } else {
                if (!creep.pos.isNearTo(my_spawns[0])) {
                    creep.moveTo(my_spawns[0]);
                }
            }
            
            
        } 
        // --helper logic end--
        
    }
};

module.exports = roleHelper;