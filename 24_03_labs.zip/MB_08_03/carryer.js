

var roleCarryer = {

    run: function(creep, my_storage, containers_no_sort) {
        // --carryer logic start--
        creep.say("📦");
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        }
        creep.memory.dest = creep.name.split('Carryer')[1] - 1;
        
        
        // console.log(sources[0].pos);
        
        if (!creep.memory.full) {
            if (containers_no_sort && containers_no_sort[creep.memory.dest]) {
                if(creep.withdraw(containers_no_sort[creep.memory.dest], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(containers_no_sort[creep.memory.dest])) {
                        creep.moveTo(containers_no_sort[creep.memory.dest]);
                    }
                }
            }
        } else if (creep.memory.full) {
            if (my_storage && my_storage.store["energy"] < 400000) {
                if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_storage)) {
                        creep.moveTo(my_storage);
                    }
                }
            } else if (my_storage) {
                if (!creep.pos.isNearTo(my_storage)) {
                    creep.moveTo(my_storage);
                }
            }
        } 
    } 
         
        // --carryer logic end--
        
}


module.exports = roleCarryer;