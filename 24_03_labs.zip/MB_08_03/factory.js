
var roleFactory = {

    run: function(my_factory) {
        // --Factory logic start--
        
        
        
        
        
         // --Factory logic end--
    } 
}

module.exports = roleFactory;