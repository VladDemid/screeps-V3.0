var cpu_avg = 0,
    cpu_i = 1;
    
    
module.exports.create_name = function create_name(role, max_role_creeps, start_room) {
    var export_name;
    do {
        export_name = start_room + "_" +role + this.random_Integer(1, max_role_creeps);
    } while (Game.creeps[export_name]);
    return export_name;
}

module.exports.show_time = function show_time() {
    console.log('             -- ', Date().split('2020')[1].split('GMT')[0], " --");
}


module.exports.random_Integer = function random_Integer(min, max) {
  // случайное число от min до (max+1)
  let rand = min + Math.random() * (max + 1 - min);
  return Math.floor(rand);
}  

module.exports.scout_go = function scout_go(creep, target_room) {
    const route = Game.map.findRoute(creep.room, target_room, {
    routeCallback(roomName, fromRoomName) {
        if(roomName == 'E33N48'  /*|| roomName == 'E33N50' || roomName == 'W10S38'*/ ) {    // avoid this room
            return Infinity;
        }
        return 1;
    }});
    if(route.length > 0) {
        const exit = creep.pos.findClosestByRange(route[0].exit);
        creep.moveTo(exit);
    }    
}

module.exports.go_to = function go_to(creep, target_room) {
    const route = Game.map.findRoute(creep.room, target_room);
    if(route.length > 0) {
        const exit = creep.pos.findClosestByRange(route[0].exit);
        creep.moveTo(exit);
    }    
}

module.exports.cpu_used = function cpu_used() {
    const n = 50;
    // 
    cpu_avg = cpu_avg + Game.cpu.getUsed(); 
    if (cpu_i >= n) {
        console.log('last 50 ticks cpu_avg usage: '+ (cpu_avg/n).toFixed(2));
        cpu_i = 1;
        cpu_avg = 0;
    }
    cpu_i++;
}

module.exports.market_deals_rar = function market_deals_rar(my_terminal) {
    var best_orders = [];
        const targetRoom = "W15S39";
        best_orders = Game.market.getAllOrders(order => 
                    order.type == ORDER_BUY &&
                    order.resourceType == "energy" &&
                    order.price >= 0.04 &&
                    Game.market.calcTransactionCost(1000, targetRoom, order.roomName) < 850);
                    
    best_orders.sort((a,b) => b.price - a.price);
    if (best_orders[0]) {
        
        const summ = best_orders[0].amount + Game.market.calcTransactionCost(best_orders[0].amount, targetRoom, best_orders[0].roomName);
        const tax = Game.market.calcTransactionCost(1000, targetRoom, best_orders[0].roomName)/1000;
        const to_pay_tax = tax + 1;
        const to_pay = ((my_terminal.store["energy"]-2000)/to_pay_tax).toFixed();
        
        // console.log("    --new best deal--\n", best_orders[0].id, "\n", best_orders[0].resourceType
        // , "\n", best_orders[0].price, "\n", best_orders[0].amount, "\n"
        // ,"tax: ",tax , "\n"
        // , "need to pay:", summ );
        
       
        Game.market.deal(best_orders[0].id, to_pay, targetRoom);
        console.log("--transaction completed$--");
        
    } 
    // else {
    //     console.log("no good energy deals found");
    // }
}



module.exports.market_sell_overflow = function market_sell_overflow(my_terminal, my_mineral_type, my_room) {
    var current_order,
        avg_price = 0,
        my_price,
        now_orders;
        
    current_order = Game.market.getAllOrders(order => order.resourceType == my_mineral_type &&
    order.roomName == my_room)[0];
    
    if (!current_order) {
        for (var n = 7; n < 14; n++) {
            avg_price = avg_price + Game.market.getHistory(my_mineral_type)[n].avgPrice;
        }
        avg_price = avg_price/7;
        now_orders = Game.market.getAllOrders(order => order.resourceType == my_mineral_type &&
        order.type == ORDER_SELL);
        best_order = _.min(now_orders, 'price')
        
        if ( best_order.price * 1.1 >= avg_price) {
            if (best_order.price > 1.5 * avg_price) {
                my_price = (avg_price * 1.5).toFixed(3);
            } else {
                my_price = (best_order.price - 0.001).toFixed(3);
            }
            
            // console.log("my_price:",my_price, "|best_order:", best_order.price, "|avg_price:", avg_price.toFixed(3), "|type:", my_mineral_type, "|room:", my_room);
            Game.market.createOrder({
                type: ORDER_SELL,
                resourceType: my_mineral_type,
                price: my_price,
                totalAmount: 10000,
                roomName: my_room   
            });
            console.log("--ORDER CREATED--", my_room, my_mineral_type);
        } else {
            console.log(my_room, my_mineral_type, "waiting for best economy");
        }
    } 
    
}

module.exports.check_old_orders = function check_old_orders(my_terminal, my_mineral_type, my_room) {
    var current_order,
        avg_price = 0,
        my_price,
        now_orders;
    
    current_order = Game.market.getAllOrders(order => order.resourceType == my_mineral_type &&
    order.roomName == my_room)[0]; //мой
    
    if (current_order) {
        now_orders = Game.market.getAllOrders(order => order.resourceType == my_mineral_type &&
        order.type == ORDER_SELL);//все по данному минералу
        best_order = _.min(now_orders, 'price') //самый дешевый
        
        if (current_order.price > best_order.price) {
            Game.market.changeOrderPrice(current_order.id, best_order.price);
            console.log(my_room, my_mineral_type, "--PRICE CHANGED--", best_order.price);
        } else {
            console.log(my_room, my_mineral_type, "--my price the best--");
        }
    }
}



module.exports.spawn_creep = function spawn_creep(role, max_role_creeps, spawning_lvl, spawner, start_room) {
    if (spawning_lvl == 1) { //300
        console.log("1-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK, WORK, CARRY, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([MOVE,MOVE,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        }
    } else if (spawning_lvl == 2) { //550
        console.log("2-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,CARRY,CARRY,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Attacker":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([ATTACK,ATTACK,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Helper":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        }
    } else if (spawning_lvl == 3) { //800
        console.log("3-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Attacker":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Claimer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CLAIM,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Towner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Helper":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Scout":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        }
    } else if (spawning_lvl == 4) { //1300
        console.log("4-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY, CARRY, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Attacker":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Claimer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CLAIM,MOVE,CLAIM,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Towner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Helper":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Scout":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Carryer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        } 
    } else if (spawning_lvl == 5) { //1800
        console.log("5-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY, CARRY, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Attacker":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Claimer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CLAIM,MOVE,CLAIM,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Towner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Helper":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Scout":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Carryer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Collector":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Laborant":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Extractor":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        } 
    } else {console.log("error spawningg lvl", start_room);}
}