
var roleStarter = {

    run: function(creep, my_spawns, sources, extensions_mass, towers_mass, starter_max, my_controller, my_storage) {
        // --starter logic start--
        creep.say("⛽️");
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        }
        // console.log(sources[0].pos);
        if (starter_max) {
            if (!creep.memory.full) {
                if (my_storage && my_storage.store["energy"] > 0) {
                    if(creep.withdraw(my_storage, "energy") == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(my_storage)) {
                            creep.moveTo(my_storage);
                        } 
                    }
                } else {
                    const my_container = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                        filter: (i) => i.structureType == STRUCTURE_CONTAINER && i.store["energy"] > 0
                    });
                    if (my_container && my_container.store["energy"] > 0) {
                        if(creep.withdraw(my_container, "energy") == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(my_container)) {
                                creep.moveTo(my_container);
                            } 
                        }
                    } else if (creep.harvest(sources[0]) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(sources[0]);
                    }
                }
                
            } else if (creep.memory.full) {
                // console.log(my_spawns[0].store["energy"], my_spawns[0].store.getCapacity());
                if (my_spawns[0].store["energy"] < 300) {
                    if(creep.transfer(my_spawns[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_spawns[0]);
                    }
                } else if (extensions_mass[0] && extensions_mass[0].store.getFreeCapacity("energy") > 0) {
                    const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                    if  (range_1_str) {
                        for (var y = 0; y < range_1_str.length;y++) {
                            if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                                creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                                creep.moveTo(extensions_mass[0]); //move к самому незаполненному (потому что можно)
                            }
                        }
                    } else if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(extensions_mass[0]);
                    }
                    if(creep.transfer(extensions_mass[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extensions_mass[0]);
                    }
                } else if (towers_mass.length && towers_mass[0].store["energy"] < 800) {
                    if(creep.transfer(towers_mass[0], "energy") == ERR_NOT_IN_RANGE) {
                        creep.moveTo(towers_mass[0]);
                    }
                } else {
                    if (!creep.pos.isNearTo(my_spawns[0])) {
                        creep.moveTo(my_spawns[0]);
                    }
                }
            } 
        } else {
            if (!creep.pos.inRangeTo(my_controller, 4)) {
                creep.moveTo(my_controller);
            }
        }
        
        
        // --starter logic end--
        
    }
};

module.exports = roleStarter;