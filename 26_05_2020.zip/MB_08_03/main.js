var starter_max = [], miner_max = [], upgrader_max = [],
    attacker_max = [], claimer_max = [], towner_max = [], helper_max = [],
    scout_max = [], defender_max = [], carryer_max = [], collector_max = [],
    laborant_max = [],  extractor_max = [], scientist_max = [], fixer_max = [],
    repairer_max =[],
    my_spawns = [], my_spawns0 = [], my_spawns_id = [], sources = [], containers_no_sort = [], spawner = [], my_controller = [],
    my_storage = [], my_storage_id = [], my_terminal = [], my_terminal_id = [],  my_factory = [], my_factory_id = [], 
    my_extractor = [], my_extractor_id = [], my_nuker = [], my_nuker_id = [],
    my_structures = [], constructions_sites = [],
    low_creeps = [], turret_cpu = [], turret_cpu_long = [],
    rooms_need_help, room_min_def_hit_need = [], room_min_def_hit_now = [],
    my_rooms2 = [], main_room, link_to = [], link_from = [], labs = [], labs0 = [], inputLabs = [], inputLabs0 = [], boostLab = [], boostLab_id = [], boostlab0 = [], lab, labs_id = [], inputlabs_id = [], 
    extensions_mass = [], extensions_mass0 = [], extensions_mass_id = [], containers_mass = [], ext_count = [], 
    towers_mass = [], towers_mass0 = [], towers_mass_id = [], towers_mass2 = [], my_mineral = [], my_mineral_id = [], 
    my_mineral_type = [], spawning_lvl = [], creep_alarm = [], enemy = [], help_need = [], found_helper = [], my_orders, orders_num,
    creeps_number, global_i = 0, global_i_max, cpu_test = [];
    if (!Memory.compound_fusion) {
        Memory.compound_fusion = [];
    }
    
    
    starter_count = [],
    upgrader_count = [],
    miner_count = [],
    carryer_max = [],
    claimer_count = [],
    attacker_count = [],
    towner_count = [],
    helper_count = [],
    scout_count = [],
    defender_count = [],
    carryer_count = [],
    collector_count = [],
    laborant_count = [],
    extractor_count = [],
    scientist_count = [],
    fixer_count = [],
    repairer_count = [],

    funcs = require("funcs"),
    roleMiner = require("miner"),
    roleUpgrader = require("upgrader"),
    roleAttacker = require("attacker"),
    roleTower = require("tower"),
    roleClaimer = require("claimer"),
    roleTowner = require("towner"),
    roleHelper = require("helper"),
    roleScout = require("scout"),
    roleDefender = require("defender"),
    roleCarryer = require("carryer"),
    roleCollector = require("collector"),
    roleLaborant = require("laborant"),
    roleExtractor = require("extractor"),
    roleScientist = require("scientist"),
    roleRepairer = require("repairer"),
    roleFactory = require("factory");
    roleStarter = require("starter");
    roleFixer = require("fixer");
    
    my_rooms = ["E32N44", "E32N48", "E33N49", "E33N44", "E34N48", "E37N49", "E39N51", "E33N41", "E34N47"];
    main_room = "E32N44";
    
function which_room(start_room) {
    // console.log(start_room);
    var r;
    for (var i = 0; i < my_rooms.length; i++) {
        if (start_room == my_rooms[i]) {
            r = i;
            break;
        }
    }
    return r;
}


function spawn_start (spawner, i) {
    if (starter_count[i] < starter_max[i]) {
        funcs.spawn_creep("Starter", starter_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (miner_count[i] < miner_max[i]) {
        funcs.spawn_creep("Miner", miner_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (helper_count[i] < helper_max[i]) {
        funcs.spawn_creep("Helper", helper_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (carryer_count[i] < carryer_max[i]) {
        funcs.spawn_creep("Carryer", carryer_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (defender_count[i] < defender_max[i]) {
        funcs.spawn_creep("Defender", defender_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (laborant_count[i] < laborant_max[i]) {
        funcs.spawn_creep("Laborant", laborant_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (upgrader_count[i] < upgrader_max[i]) {
        funcs.spawn_creep("Upgrader", upgrader_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (attacker_count[i] < attacker_max[i]) {
        funcs.spawn_creep("Attacker", attacker_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (claimer_count[i] < claimer_max[i]) {
        funcs.spawn_creep("Claimer", claimer_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (towner_count[i] < towner_max[i]) {
        funcs.spawn_creep("Towner", towner_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (scout_count[i] < scout_max[i]) {
        funcs.spawn_creep("Scout", scout_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (collector_count[i] < collector_max[i]) {
        funcs.spawn_creep("Extractor", collector_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (extractor_count[i] < extractor_max[i]) {
        funcs.spawn_creep("Extractor", extractor_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (scientist_count[i] < scientist_max[i]) {
        funcs.spawn_creep("Scientist", scientist_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (fixer_count[i] < fixer_max[i]) {
        funcs.spawn_creep("Fixer", fixer_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (repairer_count[i] < repairer_max[i]) {
        funcs.spawn_creep("Repairer", repairer_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } 
    
    
}

module.exports.loop = function () {
    rooms_need_help = 0;
    
    // var nuklear_launch = '<p style="background:repeating-linear-gradient(-45deg, #f7df01, #f7df01 5px, #030f10 5px, #030f10 10px) fixed; color: red; font-weight:bold;font-size:20px;text-shadow: 1px 1px 1px black;box-shadow: inset 0px 0px 5px 2px rgba(0,0,0,0.75);padding:0 15px">NUKLEAR LAUNCH DETECTED</p>'
    // if (global_i == 1) {
    //     console.log("----------------");
    // }
    global_i++;
    global_i_max = 5;
    if (global_i > global_i_max) {global_i = 1}
    // console.log("------------");
    // my_rooms = _.filter(Game.rooms, room=> room.controller && room.controller.my)
    
    
    creeps_number = 0;
    // var cpu_test = Game.cpu.getUsed();
    // cpu_test = Game.cpu.getUsed() - cpu_test - 0.002;
    // console.log(cpu_test.toFixed(4));
    for (var i = 0; i < my_rooms.length; i++) { // проход по румам
        if (!rooms_need_help && Game.rooms[my_rooms[i]].controller.level < 8) { //поиск нуждающихся рум
            rooms_need_help = Game.rooms[my_rooms[i]];
            // console.log(Game.rooms[my_rooms[i]]);
        } 
        var cpu_test_room = Game.cpu.getUsed();
        
        starter_count[i] = 0;
        miner_count[i] = 0;
        upgrader_count[i] = 0;
        towner_count[i] = 0;
        scout_count[i] = 0;
        defender_count[i] = 0;
        carryer_count[i] = 0;
        helper_count[i] = 0;
        attacker_count[i] = 0;
        claimer_count[i] = 0;
        collector_count[i] = 0;
        laborant_count[i] = 0;
        extractor_count[i] = 0;
        scientist_count[i] = 0;
        repairer_count[i] = 0;
        fixer_count[i] = 0;
        creep_alarm[i] = 0;
        
        if (global_i == 1) {
            //сначала условия присутствия зданий
            
            // if (my_rooms[i] == "E32N44") {
            
            my_structures[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES
            // , {
                // filter: (i) => /*i.structureType != "extension"
                            // &&*/ 
                            // i.structureType != "rampart"
            // }
            );
            constructions_sites[i] = 0;
            my_spawns0[i] = [];
            towers_mass0[i] = [];
            extensions_mass0[i] = [];
            room_min_def_hit_now[i] = 0;
            for (my_structure of my_structures[i]) {
                switch (my_structure.structureType) {
                    case "extension":
                        extensions_mass0[i].push(my_structure);
                        break;
                    case "tower":
                        towers_mass0[i].push(my_structure);
                        break;
                    case "storage":
                        my_storage_id[i] = my_structure.id;
                        break;
                    case "terminal":
                        my_terminal_id[i] = my_structure.id;
                        break;
                    case "factory":
                        my_factory_id[i] = my_structure.id;
                        break;
                    case "extractor":
                        my_extractor_id[i] = my_structure.id;
                        break;
                    case "spawn":
                        my_spawns0[i].push(my_structure);
                        break;
                    case "nuker":
                        my_nuker_id[i] = my_structure.id;
                        break;
                    case "rampart":
                        if(!room_min_def_hit_now[i] || room_min_def_hit_now[i] > my_structure.hits) {
                            room_min_def_hit_now[i] = my_structure.hits;
                        }
                        break;
                    default:
                        break;
                        
                }
            }
            // }
            // if (Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_STORAGE}})[0]) {
            //     my_storage_id[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_STORAGE}})[0].id;
            // }
            // if (Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_TERMINAL}})[0]) {
            //     my_terminal_id[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_TERMINAL}})[0].id;
            // }
            // if (Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_FACTORY}})[0]) {
            //     my_factory_id[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_FACTORY}})[0].id;
            // }
            // if (Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_EXTRACTOR}})[0]) {
            //     my_extractor_id[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_EXTRACTOR}})[0].id;
            // }
            
            // my_nuker_id[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_NUKER}})[0].id; 
            // console.log(my_nuker_id[i]);
            my_mineral_id[i] = Game.rooms[my_rooms[i]].find(FIND_MINERALS)[0].id;
            
            // my_spawns0[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_SPAWN}});
            my_spawns_id[i] = [];
            for (var s = 0; s < my_spawns0[i].length; s++) {
                my_spawns_id[i][s] = my_spawns0[i][s].id;
                // console.log(my_spawns_id[i][0]);
            }
            
            // towers_mass0[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_TOWER}});
            towers_mass_id[i] = [];
            for (var t = 0; t < towers_mass0[i].length; t++) {
                towers_mass_id[i][t] = towers_mass0[i][t].id;
                // console.log(my_spawns_id[i][0]);
            }
            // console.log(towers_mass_id[i][0]);
            
            // extensions_mass0[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_EXTENSION}});
            extensions_mass_id[i] = [];
            for (var e = 0; e < extensions_mass0[i].length; e++) {
                extensions_mass_id[i][e] = extensions_mass0[i][e].id;
                // console.log(my_spawns_id[i][0]);
            }
            
            constructions_sites[i] = Game.rooms[my_rooms[i]].find(FIND_MY_CONSTRUCTION_SITES)[0];
            
            my_orders = Game.market.orders;
            if (Game.time % 3 == 0) {
                low_creeps[i] = Game.rooms[my_rooms[i]].find(FIND_MY_CREEPS, {
                    filter: (i) => i.hits < i.hitsMax
                })[0];
            } else {low_creeps[i] = 0}
            
                // filter: function(object) {
                //     return object.hits < object.hitsMax;
                // }
            
            // if (Game.rooms[my_rooms[i]].controller.level >= 6) {
            //     labs0[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_LAB}});
            //     if (labs0[i].length >= 6) {
            //         inputLabs0[i] = [];
            //         for (lab of labs0[i]) {
            //             if (lab.pos.findInRange(FIND_MY_STRUCTURES, 2, {filter: {structureType: STRUCTURE_LAB}}).length == labs0[i].length) {
            //                 inputLabs0[i].push(lab);
            //             }
            //             if (inputLabs0[i].length == 2) {
            //                 break;
            //             }
            //         }
            //         labs_id[i] = [];
            //         inputlabs_id[i] = [];
            //         for (var l = 0; l < inputLabs0[i].length; l++) {
            //             inputlabs_id[i][l] = inputLabs0[i][l].id;
            //             // console.log(inputlabs_id[i][l]);
            //         }
            //         for (var l = 0; l < labs0[i].length; l++) {
            //             labs_id[i][l] = labs0[i][l].id;
            //             // console.log(inputlabs_id[i][l]);
            //         }
            //     }
            // }
            if (Game.rooms[my_rooms[i]].controller.level >= 6) {
                labs0[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_LAB}});
                if (labs0[i].length >= 1) {
                    if (Game.rooms[my_rooms[i]].terminal) {
                        boostlab0[i] = Game.rooms[my_rooms[i]].terminal.pos.findClosestByRange(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_LAB}});
                        boostLab_id[i] = boostlab0[i].id;
                    }
                    // if (labs0[i].length >= 6) {
                    //     for (lab of labs0[i]) {
                    //         if (lab.id == boostLab_id[i]) {
                    //             labs0[i].splice(labs0[i].indexOf(lab), 1);
                    //         }
                    //     }
                    //     inputlabs_id[i] = [];
                    //     inputlabs_id[i][0] = labs0[i][0];
                    //     inputlabs_id[i][1] = labs0[i][1];
                    //     console.log(my_rooms[i], inputlabs_id[i].length, labs0[i].length);
                    // }
                }
            }
        }
        
        // console.log(my_rooms[i],room_min_def_hit_now[i]);
        
        if (Game.rooms[my_rooms[i]].controller.level == 1) {
            miner_max = 0;
        }
    
        my_controller[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTROLLER}})[0];
        if ( !ext_count[i] || ext_count[i] < 40 ) {
            containers_mass[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}});
            containers_no_sort[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}});
            containers_mass[i].sort((a,b) => a.store["energy"] - b.store["energy"]);
        }
        
        
        my_storage[i] = Game.getObjectById(my_storage_id[i]);
        my_factory[i] = Game.getObjectById(my_factory_id[i]);
        
        
        my_mineral[i] = Game.getObjectById(my_mineral_id[i]);
        my_mineral_type[i] = my_mineral[i].mineralType;
        
        
        my_terminal[i] = Game.getObjectById(my_terminal_id[i]);
        my_extractor[i] = Game.getObjectById(my_extractor_id[i]);
        
        my_nuker[i] = Game.getObjectById(my_nuker_id[i]);
        
        // my_spawns[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_SPAWN}});
        my_spawns[i] = [];
        
        
        
        for (var s = 0; s < my_spawns_id[i].length; s++) {
            my_spawns[i][s] = Game.getObjectById(my_spawns_id[i][s]);
        }
        
        
        
        
        
        
        my_spawns[i].sort((a,b) => a.store[RESOURCE_ENERGY] - b.store[RESOURCE_ENERGY]);
        if (my_spawns[i].length > 1) {
            if (my_spawns[i][0].spawning) {
                spawner[i] = my_spawns[i][1];
            } else { spawner[i] = my_spawns[i][0]; }
        } else { spawner[i] = my_spawns[i][0]; }
        
        // towers_mass[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_TOWER}});
        
        
        towers_mass[i] = [];
        for (var s = 0; s < towers_mass_id[i].length; s++) {
            towers_mass[i][s] = Game.getObjectById(towers_mass_id[i][s]);
        }
       
        
        
        // console.log(towers_mass2[i][0]);
        
        towers_mass[i].sort((a,b) => a.store[RESOURCE_ENERGY] - b.store[RESOURCE_ENERGY]);
        if (towers_mass[i].length) {
            enemy[i] = towers_mass[i][0].pos.findClosestByRange(FIND_HOSTILE_CREEPS);
        } else {
            enemy[i] = Game.rooms[my_rooms[i]].find(FIND_HOSTILE_CREEPS)[0];
        }
        
        turret_cpu[i] = 0;
        if (towers_mass[i].length) {
            for (t = 0; t < towers_mass[i].length; ++t) {
                var cpu_test_tower = Game.cpu.getUsed();
                roleTower.run(towers_mass[i][t], enemy[i], t, towers_mass[i].length, low_creeps[i]); // оптимизировать
                cpu_test_tower = Game.cpu.getUsed() - cpu_test_tower - 0.002;
                turret_cpu[i] = turret_cpu[i] + cpu_test_tower;
                new RoomVisual(towers_mass[i][t].room.name).text(cpu_test_tower.toFixed(3) , towers_mass[i][t].pos.x, towers_mass[i][t].pos.y+0.5, {color: "grey", font: 0.3, stroke: "black", strokeWidth: 0.1});
            }
        }
        new RoomVisual(my_rooms[i]).text("turrets cpu 1 tick: "+turret_cpu[i].toFixed(3) , 22, 48, {align: "left",color: "grey", font: 0.5, stroke: "black", strokeWidth: 0.1});
        
        
        
    
        if (inputlabs_id[i] && inputlabs_id[i].length) {
            inputLabs[i] = [];
            for (var l = 0; l < inputlabs_id[i].length; l++) {
                inputLabs[i][l] = Game.getObjectById(inputlabs_id[i][l]);
                new RoomVisual(my_rooms[i]).text("*" , inputLabs[i][l].pos.x, inputLabs[i][l].pos.y+0.72, {color: "white", font: 0.6, stroke: "black", strokeWidth: 0.1});
            }
        }
        if (labs_id[i] && labs_id[i].length) {
            labs[i] = [];
            for (var l = 0; l < labs_id[i].length; l++) {
                labs[i][l] = Game.getObjectById(labs_id[i][l]);
                new RoomVisual(my_rooms[i]).text("*" , labs[i][l].pos.x, labs[i][l].pos.y+0, {color: "black", font: 0.6, stroke: "black", strokeWidth: 0.0});
            }
        }
        
        
        
        
        
        
        
        // extensions_mass[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_EXTENSION}});
        
        extensions_mass[i] = [];
        for (var e = 0; e < extensions_mass_id[i].length; e++) {
            extensions_mass[i][e] = Game.getObjectById(extensions_mass_id[i][e]);
        }
        ext_count[i] = extensions_mass[i].length;
        if (Game.rooms[my_rooms[i]].energyAvailable < Game.rooms[my_rooms[i]].energyCapacityAvailable) {
            extensions_mass[i].sort((a,b) => a.energy - b.energy);
        }
        
        
        if (Game.rooms[my_rooms[i]].controller.level >= 6 && my_storage[i]) {
            link_to[i] = my_storage[i].pos.findClosestByRange(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_LINK}});
            if (link_to[i]) {
                link_from[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {
                    filter: (l) => l.structureType == "link" 
                                && l.id != link_to[i].id
                });
            }
        }
        if (link_to[i] && link_from[i].length == 2) {
            for (var l = 0; l < link_from[i].length; l++) {
                const link = link_from[i][l];
                if (link.store["energy"] >= 700 && link.cooldown == 0 && link_to[i].store["energy"] == 0) {
                    link.transferEnergy(link_to[i]);
                    break;
                }
            }
        }    
        
        if (ext_count[i] <= 4) {
            spawning_lvl[i] = 1;
        } else if (5 <= ext_count[i] && ext_count[i] <= 9) {
            spawning_lvl[i] = 2;
        } else if (10 <= ext_count[i] && ext_count[i] <= 19) {
            spawning_lvl[i] = 3;
        } else if (20 <= ext_count[i] && ext_count[i] <= 29) {
            spawning_lvl[i] = 4;
        } else if (30 <= ext_count[i] && ext_count[i] <= 49) {
            spawning_lvl[i] = 5;
        } else if (50 <= ext_count[i] && ext_count[i] <= 59) {
            spawning_lvl[i] = 6;
        } else if (60 <= ext_count[i]) {
            spawning_lvl[i] = 7;
        }
        
        sources[i] = Game.rooms[my_rooms[i]].find(FIND_SOURCES);
        
        switch (spawning_lvl[i]) {
            case 1:
                starter_max[i] = 1,
                upgrader_max[i] = 2;
                break;
            case 2:
                starter_max[i] = 0,
                upgrader_max[i] = 2;
                helper_max[i] = 1;
                break;
            case 3:
                starter_max[i] = 0,
                upgrader_max[i] = 2;
                helper_max[i] = 1;
                break;
            case 4:
                starter_max[i] = 0,
                upgrader_max[i] = 2;
                helper_max[i] = 1;
                carryer_max[i] = 2;
                break;
            case 5:
                starter_max[i] = 0,
                upgrader_max[i] = 2;
                helper_max[i] = 1;
                carryer_max[i] = 2;
                break;
            case 6:
                starter_max[i] = 0,
                upgrader_max[i] = 2;
                helper_max[i] = 1;
                scientist_max[i] = 1;
                break;
            case 7:
                starter_max[i] = 0,
                upgrader_max[i] = 1;
                helper_max[i] = 1;
                scientist_max[i] = 1;
                break;
        }     
        
        
        switch (Game.rooms[my_rooms[i]].controller.level) {
            case 6:
                room_min_def_hit_need[i] = 250000;
                break;
            case 7:
                room_min_def_hit_need[i] = 1000000;
                break;
            case 8:
                room_min_def_hit_need[i] = 20000000;
                break;
            default:
                room_min_def_hit_need[i] = 0;
                break;
        }
        // if (my_rooms[i] == "E33N41") {
        //     console.log(room_min_def_hit_now[i]);
        // }
        
        if (my_storage[i] && my_storage[i].store["energy"] > 45000 && room_min_def_hit_now[i] && room_min_def_hit_need[i] && room_min_def_hit_now[i] < room_min_def_hit_need[i]) {
            if (Game.rooms[my_rooms[i]].controller.level == 8) {
                repairer_max[i] = 2;
            } else {
                repairer_max[i] = 1;
            }
            
            // console.log(my_rooms[i], "need repeir");
        } else {
            repairer_max[i] = 0;
        }
        if (repairer_max[i] >= 1 && my_storage[i].store["energy"] > 300000) {
            repairer_max[i] = 4
        }
        
        
        
        if (link_to[i]) {
            laborant_max[i] = 1;
        }
        if (spawning_lvl[i] >= 5 && laborant_max[i]) {
            carryer_max[i] = 0;
        }
        if (ext_count[i] && ext_count[i] >= 40 && my_mineral[i].mineralAmount > 0 && my_terminal[i] && my_terminal[i].store[my_mineral_type[i]] < 150000) {
            extractor_max[i] = 2;
        } else {
            extractor_max[i] = 0
        }
        miner_max[i] = sources[i].length;
        if (my_storage[i] && spawning_lvl[i] >= 4 && spawning_lvl[i] < 7) {
            if (my_storage[i].store["energy"] < 50000 && upgrader_max[i] > 1) {
                upgrader_max[i] = 1;
            } else if (my_storage[i].store["energy"] > 100000 && upgrader_max[i] < 4) {
                upgrader_max[i] = 4;
            }
        } else if (spawning_lvl[i] < 4 && containers_mass[i].length && containers_mass[i][containers_mass[i].length - 1].store["energy"] > 1800 && upgrader_max[i] > 1) {
            upgrader_max[i] = 4;
        }
        if (my_controller[i].level == 8 && !constructions_sites[i] && my_controller[i].ticksToDowngrade > 130000 && upgrader_max[i] > 0) {
            upgrader_max[i] = 0;
        }
        if (my_terminal[i] && Game.time % 500 == 0 && Object.keys(Game.market.orders).length < 300) {
            if (my_terminal[i].store[my_mineral_type[i]] > 40000) {
                funcs.market_sell_overflow(my_terminal[i], my_mineral_type[i], my_rooms[i]);
            }
            // if (my_terminal[i].store["energy"] > 50000) {
            //     funcs.market_sell_overflow(my_terminal[i], "energy", my_rooms[i]);
            // }
            funcs.check_old_orders(my_terminal[i], my_mineral_type[i], my_rooms[i]);
        }
        if (my_factory[i]) {
            roleFactory.run(my_factory[i], my_storage[i], my_terminal[i]); 
        }
        
        if (my_rooms[i] == "E32N44") {
            
            attacker_max[i] = 0;
            claimer_max[i] = 0;
            // scout_max[i] = 1;
            towner_max[i] = 0;
            
        } else if (my_rooms[i] == "E32N48") {
            attacker_max[i] = 0;
            claimer_max[i] = 0;
            towner_max[i] = 0;
        } else if (my_rooms[i] == "E33N49") {
            attacker_max[i] = 0;
            claimer_max[i] = 0;
            collector_max[i] = 0;
            towner_max[i] = 0;
        } else if (my_rooms[i] == "E33N44") {
            if (spawning_lvl[i] < 4) {
                upgrader_max[i] = 4;
            }
        } else if(my_rooms[i] == "E34N48") {
            
        } else if(my_rooms[i] == "E37N49") {
            attacker_max[i] = 0;
            claimer_max[i] = 0;
            towner_max[i] = 0;
        } else if(my_rooms[i] == "E39N51") {
            fixer_max[i] = 1;
            // if (starter_max == 1) {
            //     starter_max = 2;
            // }
        }
        
        if (!towers_mass[i] || towers_mass[i].length < 2) {
            defender_max[i] = 2;
        } else {
            defender_max[i] = 0;
        }
        
        found_helper[i] = Game.rooms[my_rooms[i]].find(FIND_MY_CREEPS, {
            filter: (i) => i.memory.role == "Helper"
        })[0];
        if (found_helper[i]) {
            help_need[i] = 0
        } else {
            help_need[i] = 1
        }
        
        if (help_need[i] && Game.rooms[my_rooms[i]].energyAvailable < Game.rooms[my_rooms[i]].energyCapacityAvailable) {
            starter_max[i] = 1;
        }
        
        if (Game.rooms[my_rooms[i]] == "E32N44") {
            console.log("starter_max=",starter_max[i]);
        }
        cpu_test_room = Game.cpu.getUsed() - cpu_test_room - 0.002;
        new RoomVisual(my_rooms[i]).text("room CPU: "+cpu_test_room.toFixed(3)+" Bucket: "+Game.cpu.bucket , 21, 49, {color: "grey", font: 0.6, stroke: "black", strokeWidth: 0.1, align: "left"});
    }
    
    
    for (var name in Game.creeps) { // проход по крипам
        var creep = Game.creeps[name];
        const r = which_room(creep.memory.start_room);
        var cpu_test = Game.cpu.getUsed();
        
        // console.log(creep.memory.start_room);
        creeps_number++;
        if (!creep.spawning) {
            if (creep.memory.role == "Starter") {
                starter_count[r]++;
                roleStarter.run(creep, my_spawns[r], sources[r], extensions_mass[r], towers_mass[r], starter_max[r], my_controller[r], my_storage[r]);
            } else if (creep.memory.role == "Miner") {
                miner_count[r]++;
                roleMiner.run(creep, my_spawns[r], sources[r], link_to[r], link_from[r], laborant_max[r]);
            } else if (creep.memory.role == "Upgrader") {
                upgrader_count[r]++;
                roleUpgrader.run(creep, my_spawns[r], sources[r], my_controller[r], containers_no_sort[r], my_storage[r], spawning_lvl[r]);
            } else if (creep.memory.role == "Attacker") {
                attacker_count[r]++;
                roleAttacker.run(creep);
            } else if (creep.memory.role == "Claimer") {
                claimer_count[r]++;
                roleClaimer.run(creep);
            } else if (creep.memory.role == "Towner") {
                towner_count[r]++;
                roleTowner.run(creep);
            } else if (creep.memory.role == "Helper") {
                helper_count[r]++;
                roleHelper.run(creep, my_spawns[r], sources[r], extensions_mass[r], towers_mass[r], containers_mass[r], my_storage[r]);
            } else if (creep.memory.role == "Scout") {
                scout_count[r]++;
                roleScout.run(creep);
            } else if (creep.memory.role == "Defender") {
                defender_count[r]++;
                roleDefender.run(creep, enemy[r]);
            } else if (creep.memory.role == "Carryer") {
                carryer_count[r]++;
                roleCarryer.run(creep, my_storage[r], containers_no_sort[r]);
            } else if (creep.memory.role == "Collector") {
                collector_count[r]++;
                roleCollector.run(creep, my_storage[r]);
            } else if (creep.memory.role == "Laborant") {
                laborant_count[r]++;
                roleLaborant.run(creep, my_storage[r], link_to[r], my_terminal[r], my_factory[r], my_nuker[r]);
            } else if (creep.memory.role == "Extractor") {
                extractor_count[r]++;
                roleExtractor.run(creep, my_storage[r], my_terminal[r], my_mineral[r], my_mineral_type[r], my_extractor[r]);
            } else if (creep.memory.role == "Scientist") {
                scientist_count[r]++;
                roleScientist.run(creep, my_storage[r], link_to[r], my_terminal[r], my_mineral_type[r], my_factory[r], inputLabs[r], labs[r], r);
            } else if (creep.memory.role == "Fixer") {
                fixer_count[r]++;
                roleFixer.run(creep, my_storage[r]);
            } else if (creep.memory.role == "Repairer") {
                repairer_count[r]++;
                roleRepairer.run(creep, my_storage[r]);
            }
        }
        cpu_test = Game.cpu.getUsed() - cpu_test;
        new RoomVisual(creep.room.name).text(cpu_test.toFixed(3) , creep.pos.x, creep.pos.y+0.5, {color: "grey", font: 0.3, stroke: "black", strokeWidth: 0.1});
    }
    
    
     
    
    for (var i = 0; i < my_rooms.length; i++) { // 2-й проход по румам
        
        
        if (Game.time % 400 == 0 && my_terminal[i] && my_terminal[i].store[my_mineral_type[i]] > 3000) {
            for (var r = 0; r < my_rooms.length; r++) {
                if (my_terminal[r] && my_terminal[r].store[my_mineral_type[i]] < 3000) {
                    my_terminal[i].send(my_mineral_type[i], 1000, my_rooms[r]);
                    // console.log(my_mineral_type[i], "sended to", my_rooms[r], "from", my_rooms[i]);
                    break;
                }
            }
        }
        
        if (spawner[i] && !spawner[i].spawning) {
            // console.log(Game.rooms[my_rooms[i]].energyCapacityAvailable);
            if (Game.rooms[my_rooms[i]].energyAvailable == Game.rooms[my_rooms[i]].energyCapacityAvailable ||
                (Game.rooms[my_rooms[i]].energyAvailable >= 300 && starter_max[i] && !starter_count[i]) ) {
                    spawn_start(spawner, i);
            }
        }
        if (my_terminal[i] && my_terminal[i].store[my_mineral_type[i]] > 0) {
            let color_c,
            my_terminal_store = my_terminal[i].store[my_mineral_type[i]];
            if (my_terminal_store > 120000) {
                color_c = "red";
            } else if (my_terminal_store > 80000) {
                color_c = "yellow";
            } else {color_c = "#76A175";}
            new RoomVisual(main_room).text(my_rooms[i]+" "+my_mineral_type[i]+" "+my_terminal[i].store[my_mineral_type[i]]
            , 0, 35+i, {color: color_c, font: 0.5, stroke: "black", strokeWidth: 0.1, align: "left"});
            
        }
        if (my_controller[i].level <= 4) {
            for (var c = 0; c < containers_mass[i].length; c++) {
                let color_c,
                c_enrg = containers_mass[i][c].store["energy"]
                if (c_enrg > 1600) {
                    color_c = "red";
                } else if (c_enrg > 800) {
                    color_c = "yellow";
                } else {color_c = "green";}
                new RoomVisual(my_rooms[i]).text((c_enrg+"🔅"), containers_mass[i][c].pos.x+0.4, 
                        containers_mass[i][c].pos.y+0.2, {color: color_c, font: 0.6, stroke: "black", strokeWidth: 0.1, align: "left"}); 
            }
        } 
        if (my_controller[i].level >= 4) {
            if (my_storage[i]) {
                let color_s,
                s_enrg = my_storage[i].store["energy"];
                if (s_enrg > 200000) {
                    color_c = "green";
                } else if (s_enrg > 50000) {
                    color_c = "yellow";
                } else {color_c = "red";}
                new RoomVisual(my_rooms[i]).text((s_enrg), my_storage[i].pos.x, 
                        my_storage[i].pos.y+0.2, {color: color_c, font: 0.5, stroke: "black", strokeWidth: 0.1}); 
            }
        }
        
    }
    
    orders_num = Object.keys(my_orders).length;
    for (var o = orders_num - 1; o >= 0 && o > (orders_num - 10)  ; o--) {
        if (my_orders[Object.keys(my_orders)[o]].active ) {
            let room_y = which_room(my_orders[Object.keys(my_orders)[o]].roomName);
            new RoomVisual(main_room).text("💰 "+my_orders[Object.keys(my_orders)[o]].amount+" "+my_orders[Object.keys(my_orders)[o]].price+"$"
            , 1.5, 34.55+room_y, {color: "green", font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        }
    }
    
    funcs.cpu_used();
    // console.log("--------------------");
    // console.log("creeps =", creeps_number);
}