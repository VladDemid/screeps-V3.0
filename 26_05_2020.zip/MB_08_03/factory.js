
var roleFactory = {

    run: function(my_factory, my_storage, my_terminal) {
        // --Factory logic start--
        
       if (my_storage && my_terminal && my_factory) {
           if (my_terminal.store['battery'] < 10000 && my_factory.store["energy"] >= 4000 && my_factory.cooldown == 0) {
               my_factory.produce('battery');
           }
       }
        
        
        
         // --Factory logic end--
    } 
}

module.exports = roleFactory;