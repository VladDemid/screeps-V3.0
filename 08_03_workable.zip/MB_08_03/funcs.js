var cpu_avg = 0,
    cpu_i = 1;
    
    
module.exports.create_name = function create_name(role, max_role_creeps, start_room) {
    var export_name;
    do {
        export_name = start_room + "_" +role + this.random_Integer(1, max_role_creeps);
    } while (Game.creeps[export_name]);
    return export_name;
}

module.exports.show_time = function show_time() {
    console.log('             -- ', Date().split('2020')[1].split('GMT')[0], " --");
}


module.exports.random_Integer = function random_Integer(min, max) {
  // случайное число от min до (max+1)
  let rand = min + Math.random() * (max + 1 - min);
  return Math.floor(rand);
}  

module.exports.scout_go = function scout_go(creep, target_room) {
    const route = Game.map.findRoute(creep.room, target_room, {
    routeCallback(roomName, fromRoomName) {
        if(roomName == 'E33N48'  /*|| roomName == 'E33N50' || roomName == 'W10S38'*/ ) {    // avoid this room
            return Infinity;
        }
        return 1;
    }});
    if(route.length > 0) {
        const exit = creep.pos.findClosestByRange(route[0].exit);
        creep.moveTo(exit);
    }    
}

module.exports.go_to = function go_to(creep, target_room) {
    const route = Game.map.findRoute(creep.room, target_room);
    if(route.length > 0) {
        const exit = creep.pos.findClosestByRange(route[0].exit);
        creep.moveTo(exit);
    }    
}

module.exports.cpu_used = function cpu_used() {
    const n = 20;
    // 
    cpu_avg = cpu_avg + Game.cpu.getUsed(); 
    if (cpu_i >= n) {
        console.log('last 20 ticks cpu_avg usage: '+ (cpu_avg/n).toFixed(2));
        cpu_i = 1;
        cpu_avg = 0;
    }
    cpu_i++;
}

module.exports.spawn_creep = function spawn_creep(role, max_role_creeps, spawning_lvl, spawner, start_room) {
    if (spawning_lvl == 1) { //300
        console.log("1-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK, WORK, CARRY, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([MOVE,MOVE,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        }
    } else if (spawning_lvl == 2) { //550
        console.log("2-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,CARRY,CARRY,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Attacker":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([ATTACK,ATTACK,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Helper":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        }
    } else if (spawning_lvl == 3) { //800
        console.log("3-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Attacker":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Claimer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CLAIM,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Towner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Helper":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Scout":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        }
    } else if (spawning_lvl == 4) { //1300
        console.log("4-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY, CARRY, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Attacker":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Claimer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CLAIM,MOVE,CLAIM,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Towner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Helper":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Scout":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Carryer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        } 
    } else if (spawning_lvl == 5) { //1800
        console.log("5-lvl", start_room, role);
        switch (role) {
            case "Miner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Upgrader":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Starter":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY, CARRY, CARRY, CARRY, MOVE, MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Attacker":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Defender":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK,ATTACK], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Claimer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CLAIM,MOVE,CLAIM,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Towner":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Helper":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Scout":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Carryer":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Collector":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Laborant":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([CARRY,CARRY,MOVE,CARRY,CARRY,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            case "Extractor":
                var temp_name = this.create_name(role, max_role_creeps, start_room);
                spawner.spawnCreep([WORK,WORK,WORK,WORK,WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE,MOVE], temp_name);
                Game.creeps[temp_name].memory.role = role;
                Game.creeps[temp_name].memory.start_room = start_room;
                break;
            default:
                console.log("not find role!!", start_room, spawning_lvl, role);
                break;
        } 
    } else {console.log("error spawningg lvl", start_room);}
}