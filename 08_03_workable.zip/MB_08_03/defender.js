funcs = require("funcs");

var roleDefender = {

    run: function(creep, enemy) {
        // --defender logic start--
        
        // const enemy_creeps = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
        if (enemy) {
            creep.say("⚔️");
            if(creep.attack(enemy) == ERR_NOT_IN_RANGE) {
                if (!creep.pos.isNearTo(enemy)) {
                    creep.moveTo(enemy);
                }
            }
        } else {
            creep.say("👀");
            if (!creep.pos.inRangeTo(25,25, 4)) {
                creep.moveTo(25,25);
            }
        }
        
        // --defender logic end--
        
    }
};

module.exports = roleDefender;