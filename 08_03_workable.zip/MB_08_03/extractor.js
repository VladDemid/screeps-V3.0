
var roleExtractor = {

    run: function(creep, my_storage, my_terminal, my_mineral, my_mineral_type) {
        // --extractor logic start--
        creep.say("☢️");
        if (creep.store.getFreeCapacity() == creep.carryCapacity) {creep.memory.full = false;}
        if (creep.store.getFreeCapacity() == 0) {creep.memory.full = true;}
                
        
        if (creep.ticksToLive > 40) {
            if (!creep.memory.full) {
                if(creep.harvest(my_mineral) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_mineral);
                }
            } else if (creep.memory.full) {
                if (my_terminal && my_terminal.store[my_mineral_type] < 50000) {
                    if(creep.transfer(my_terminal, my_mineral_type) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_terminal);
                    }
                } else {
                    if (my_storage && my_storage.store[my_mineral_type] < 300000) {
                        if(creep.transfer(my_storage, my_mineral_type) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(my_storage);
                        }
                    }
                }
                
            } 
        } else {
            if (creep.store[my_mineral_type] > 0 ) {
                if (my_storage) {
                    if(creep.transfer(my_storage, my_mineral_type) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_storage);
                    }
                }
            } else {
                creep.suicide;
            }
        }
        
    } 
         
        // --extractor logic end--
        
}

module.exports = roleExtractor;