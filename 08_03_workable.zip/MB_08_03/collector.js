funcs = require("funcs");

var roleCollertor = {

    run: function(creep, my_storage) {
        // --attacker logic start--
        creep.say("🧼");
        if (creep.memory.start_room == "E33N49") {
            creep.memory.target_room = "E33N49";
        } 
        
        if (creep.store.getUsedCapacity() == 0) {
            creep.memory.full = false;
        } else if (creep.store.getUsedCapacity() == creep.store.getCapacity() ) {
            creep.memory.full = true;
        }
        // console.log(creep.store.getFreeCapacity());
        if (creep.pos.roomName != creep.memory.target_room ) {
            creep.say("🥾⚔️");
            funcs.scout_go(creep, creep.memory.target_room);
        } else if (creep.pos.roomName == creep.memory.target_room) {
            if (!creep.memory.full) {
                const ruina = creep.pos.findClosestByRange(FIND_RUINS, {
                    filter: (i) => i.store["energy"] < i.store.getUsedCapacity()   
                });
                var ruina_res;
                if (ruina) {
                    for (i = 0; i < Object.keys(ruina.store).length; ++i) {
                        if (Object.keys(ruina.store)[i] != "energy") {
                            // console.log(ruina.pos, Object.keys(ruina.store)[i]);
                            ruina_res = Object.keys(ruina.store)[i];
                            break;
                        }
                    }
                    if(creep.withdraw(ruina, ruina_res) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(ruina)) {
                            creep.moveTo(ruina);
                        }
                    }
                }
            } else if (creep.memory.full) {
                if (my_storage && my_storage.store.getFreeCapacity() > 5000) {
                    if(creep.transfer(my_storage, Object.keys(creep.store)[0]) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(my_storage)) {
                            creep.moveTo(my_storage);
                        }
                    }
                }
            }
            
        }
        // --attacker logic end--
        
    }
};

module.exports = roleCollertor;