funcs = require("funcs");

var roleScout = {

    run: function(creep) {
        // --scout logic start--
        
        if (creep.memory.start_room == "E31N44") {
            creep.memory.target_room = "E32N44";
        } else if (creep.memory.start_room == "E32N44") {
                creep.memory.target_room = "E32N48";
        }
        
        if (creep.pos.roomName != creep.memory.target_room ) {
            creep.say("🥾");
            funcs.scout_go(creep, creep.memory.target_room);
        } else if (creep.pos.roomName == creep.memory.target_room) {
            if (!creep.pos.isNearTo(25,25)) {
                creep.moveTo(25,25);
            } 
        }
        // --scout logic end--
        
    }
};

module.exports = roleScout;