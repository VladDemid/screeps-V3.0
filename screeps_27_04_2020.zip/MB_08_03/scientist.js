scientist_funcs = require("scientist_funcs");
var 
    necessary_compounds = ["LHO2","LO", "OH", "ZK","UL","LH","UH"],
    component_of_compounds = [["LO","OH"],["L","O"],["O", "H"],["Z","K"],["U","L"],["L","H"],["U","H"]],
    ammount,
    reserve = 2500;

var roleScientist = {

    run: function(creep, my_storage, link_to, my_terminal, my_mineral_type, my_factory, inputLabs, labs, r) {
        // --laborant logic start--
        creep.say("🔬");
        if (!creep.memory.fusion) {
            creep.memory.fusion = false;
        }
        
        
        if (Game.time % 20 == 0) {
            for (compound of necessary_compounds) {
                if (my_terminal.store[compound] < reserve) {
                    creep.memory.fusion = true;
                    break;
                } else {
                    creep.memory.fusion = false;
                }
            }
        }
        if (labs && labs.length >= 6 && inputLabs && my_storage && my_terminal && my_factory && creep.memory.fusion) { //варка сплавов/бустов
            // scientist_funcs.clean_all(creep, labs, my_terminal);
            
            for (compound of necessary_compounds) {
                var component0 = component_of_compounds[necessary_compounds.indexOf(compound)][0],
                    component1 = component_of_compounds[necessary_compounds.indexOf(compound)][1],
                    component0_summ = creep.store[component0] + my_terminal.store[component0] + inputLabs[0].store[component0],
                    component1_summ = creep.store[component1] + my_terminal.store[component1] + inputLabs[1].store[component1],
                    compound_summ = false;
                    if (creep.store[compound] > 0) {
                        compound_summ = true;
                    } else {
                        for (lab of labs) {
                            if (lab.store[compound] > 0) {
                                compound_summ = true;
                            }
                        }
                    }
                if (!Memory.compound_fusion[r] || compound == Memory.compound_fusion[r] || my_terminal.store[Memory.compound_fusion[r]] >= reserve ) {
                    if (my_terminal.store[compound] < reserve && component0_summ >= reserve && component1_summ >= reserve || compound_summ) {
                        ammount = reserve - my_terminal.store[compound];
                        scientist_funcs.produce_compound(creep, component0, component1, compound, ammount, my_storage, my_terminal, my_factory, inputLabs, labs);
                        Memory.compound_fusion[r] = compound;
                        break;
                    }
                }
            }
        } else if (!creep.memory.fusion[r] && my_factory) {
            if (!creep.pos.isNearTo(my_factory)) {
                creep.moveTo(my_factory);
            }
        }
        
    } 
    
         
        // --laborant logic end--
        
}

module.exports = roleScientist;