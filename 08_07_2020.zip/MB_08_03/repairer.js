var target_fix;

var roleRepairer = {

    run: function(creep, my_storage) {
        // --roleRepairer logic start--
        creep.say("🔧");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        if (!creep.memory.timeToScan || Game.time % 150 == 0) {
            creep.memory.timeToScan = 0;
            creep.memory.timeToScan = (creep.name.split('Repairer')[1] * 30) + 150;
        }
        if (creep.memory.target_id) {
            var target = Game.getObjectById(creep.memory.target_id);
        }
        if (creep.ticksToLive == 1499 || Game.time % creep.memory.timeToScan == 0 || (creep.memory.target_id && target.hits == target.hitsMax && Game.time % 15)) {
            const targets_to_repair = creep.room.find(FIND_STRUCTURES, {filter: (o) => 
                                    o.structureType == "constructedWall"
                                || o.structureType == "rampart"
            });
            if (targets_to_repair[0]) {
                // creep.memory.target_id = targets_to_repair[0].id
                creep.memory.target_id = _.min(targets_to_repair, 'hits').id
            }
        }
        if (Game.getObjectById(creep.memory.target_id)) {
            target_fix = Game.getObjectById(creep.memory.target_id);
        }
        // console.log(creep.memory.target);
        if (!creep.memory.full) {
            if (my_storage && my_storage.store["energy"] > 20000) {
                if(creep.withdraw(my_storage, "energy") == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_storage)) {
                        creep.moveTo(my_storage, {reusePath: 8});
                    } 
                }
            } 
        } else if (creep.memory.full) {
            if (creep.memory.target_id && target_fix && target_fix.hits < target_fix.hitsMax) {
                if (creep.repair(target_fix) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(target_fix);
                }
            } else {
                if (!creep.pos.isNearTo(my_storage)) {
                    creep.moveTo(my_storage, {reusePath: 8});
                } 
            }
        }
        
        // --roleRepairer logic end--
        
    }
};

module.exports = roleRepairer;