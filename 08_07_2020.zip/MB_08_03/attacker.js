funcs = require("funcs");

var roleAttacker = {

    run: function(creep) {
        // --attacker logic start--
        
        if (creep.memory.start_room == "E31N44") {
            creep.memory.target_room = "E32N44";
        } else if (creep.memory.start_room == "E32N44") {
                creep.memory.target_room = "E33N41";
        } else if (creep.memory.start_room == "E32N48") {
                creep.memory.target_room = "E34N47";
        } else if (creep.memory.start_room == "E33N49") {
                creep.memory.target_room = "E37N49";
        } else if (creep.memory.start_room == "E37N49") {
                creep.memory.target_room = "E39N51";
        }
        
        if (creep.pos.roomName != creep.memory.target_room ) {
            creep.say("🥾⚔️");
            funcs.scout_go(creep, creep.memory.target_room);
        } else if (creep.pos.roomName == creep.memory.target_room) {
            const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 3);
            const enemy_build = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                filter: (i) => i.structureType != "controller" 
                            && i.structureType != "storage" 
                            // && i.structureType != "rampart" 
            });
            const target_by_id = Game.getObjectById("5cf9b999a37d607e7249c2ba");
            const walls = creep.pos.findClosestByRange(FIND_STRUCTURES,
                {filter: {structureType: STRUCTURE_WALL}});
            const enemy_creeps = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            if (enemy_creeps) {
                creep.say("⚔️");
                if(creep.attack(enemy_creeps) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(enemy_creeps)) {
                        creep.moveTo(enemy_creeps);
                    }
                }
            } else if (target_by_id) {
                creep.say("⚔️");
                if(creep.attack(target_by_id) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(target_by_id)) {
                        creep.moveTo(target_by_id);
                    }
                } 
            } else if (enemy_build) {
                creep.say("⚔️");
                if(creep.attack(enemy_build) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(enemy_build)) {
                        creep.moveTo(enemy_build);
                    }
                } 
            } else {
                creep.say("👀");
                if (!creep.pos.inRangeTo(25,25, 5)) {
                    creep.moveTo(25,25);
                }
            }
            
        }
        // --attacker logic end--
        
    }
};

module.exports = roleAttacker;