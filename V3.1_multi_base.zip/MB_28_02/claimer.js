var funcs = require("funcs");
    
    
var roleClaimer = {

    run: function(creep) {
        // --claimer logic start--
        
        
        creep.say("🧲");
        if (creep.memory.start_room == "E31N44") {
            creep.memory.target_room = "E33N44";
        } else if (creep.memory.start_room == "E32N44") {
            creep.memory.target_room = "E33N44";
        }
        
        // console.log(creep.room.controller.reservation.username);
        if (creep.pos.roomName != creep.memory.target_room ) {
            creep.say("🥾🧲");
            funcs.scout_go(creep, creep.memory.target_room);
        } else if (creep.pos.roomName == creep.memory.target_room) {
            if(creep.room.controller && !creep.room.controller.my) {
                if (creep.room.controller.reservation && creep.room.controller.reservation.ticksToEnd > 0) {
                    if(creep.attackController(creep.room.controller) == ERR_NOT_IN_RANGE) { //если еще зарезервирован, то аттаковать
                        creep.moveTo(creep.room.controller);
                    }
                } else if (creep.room.controller.owner && !creep.room.controller.my) {
                    if(creep.attackController(creep.room.controller) == ERR_NOT_IN_RANGE) { //если еще зарезервирован, то аттаковать
                        creep.moveTo(creep.room.controller);
                    }
                } else if (!creep.room.controller.owner) {
                    if(creep.claimController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(creep.room.controller);
                    }
                }
                
            } else {
                if (!creep.pos.isNearTo(creep.room.controller)) {
                    creep.moveTo(creep.room.controller);
                }
            }
        }
        
        // --claimer logic end--
        
    }
};

module.exports = roleClaimer;


