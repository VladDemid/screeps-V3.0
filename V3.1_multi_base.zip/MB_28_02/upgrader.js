var construction;

var roleUpgrader = {

    run: function(creep, my_spawns, sources, my_controller, containers_mass) {
        // --starter logic start--
        
        creep.say("🔋");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        // var sources = creep.room.find(FIND_SOURCES);
        
        if (!creep.memory.full) {
            var target_container;
            if (containers_mass[creep.name.split('Upgrader')[1]-1]) {
                target_container = containers_mass[creep.name.split('Upgrader')[1]-1];
            } else {
                target_container = containers_mass[0];
            }
            
            if (creep.name.split('Upgrader')[1] >= 3) {
                if (creep.name.split('Upgrader')[1] % 2 == 0) {
                    target_container = containers_mass[0];
                } else {
                    target_container = containers_mass[containers_mass.length - 1];
                }
            }
            
            if (target_container) {
                if (target_container.store["energy"] > 300) {
                    if(creep.withdraw(target_container, "energy") == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(target_container)) {
                            creep.moveTo(target_container);
                        } 
                    }
                } else {
                    if (!creep.pos.isNearTo(target_container)) {
                        creep.moveTo(target_container);
                    }
                }
            } else {
                // var sources = creep.room.find(FIND_SOURCES);
                var target_source;
                if (sources[creep.name.split('Upgrader')[1]-1]) {
                    target_source = sources[creep.name.split('Upgrader')[1]-1];
                } else {
                    target_source = sources[0];
                }
                
                if (creep.harvest(target_source) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(target_source);
                }
            }
                
        } else if (creep.memory.full) {
            
            if (Game.time % 6 == 0) {
                construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                if (construction) {
                    creep.memory.building = 1;
                } else { creep.memory.building = 0; }
            }
            // console.log(my_controller);
            
            if (creep.memory.building) {
                const new_construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                // console.log(creep.name, " building", construction);
                if(creep.build(new_construction) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(new_construction);
                }
            } else if (my_controller.level < 8 || my_controller.ticksToDowngrade < 190000) {
                if (creep.upgradeController(my_controller) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(my_controller);
                }
            }
        }
        // --starter logic end--
        
    }
};

module.exports = roleUpgrader;