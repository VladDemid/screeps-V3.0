var starter_max = [], miner_max = [], carryer_max = [], upgrader_max = [],
    attacker_max = [], claimer_max = [], towner_max = [], helper_max = [],
    scout_max = [],
    my_spawns = [], sources = [], containers_no_sort = [], spawner = [], my_controller = [],
    extensions_mass = [], containers_mass = [], ext_count = [], towers_mass = [],
    spawning_lvl = [], creep_alarm = [], enemy = [], help_need = [], found_helper = [],
    
    starter_count = [],
    upgrader_count = [],
    miner_count = [],
    carryer_max = [],
    claimer_count = [],
    attacker_count = [],
    towner_count= [],
    helper_count= [],
    scout_count= [],

    funcs = require("funcs"),
    roleMiner = require("miner"),
    roleUpgrader = require("upgrader"),
    roleAttacker = require("attacker"),
    roleTower = require("tower"),
    roleClaimer = require("claimer"),
    roleTowner = require("towner"),
    roleHelper = require("helper"),
    roleScout = require("scout"),
    roleStarter = require("starter");
    
    my_rooms = ["E31N44", "E32N44"];
    
function which_room(start_room) {
    var r;
    for (var i = 0; i < my_rooms.length; i++) {
        if (start_room == my_rooms[i]) {
            r = i;
            break;
        }
    }
    return r;
}


function spawn_start (spawner, i) {
    if (starter_count[i] < starter_max[i]) {
        funcs.spawn_creep("Starter", starter_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (helper_count[i] < helper_max[i]) {
        funcs.spawn_creep("Helper", helper_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (miner_count[i] < miner_max[i]) {
        funcs.spawn_creep("Miner", miner_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (upgrader_count[i] < upgrader_max[i]) {
        funcs.spawn_creep("Upgrader", upgrader_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (attacker_count[i] < attacker_max[i]) {
        funcs.spawn_creep("Attacker", attacker_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (claimer_count[i] < claimer_max[i]) {
        funcs.spawn_creep("Claimer", claimer_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (towner_count[i] < towner_max[i]) {
        funcs.spawn_creep("Towner", towner_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } else if (scout_count[i] < scout_max[i]) {
        funcs.spawn_creep("Scout", scout_max[i], spawning_lvl[i], spawner[i], my_rooms[i]);
    } 
    
}

module.exports.loop = function () {
    // var cpu_test = Game.cpu.getUsed();
    // cpu_test = cpu_test - Game.cpu.getUsed() + 0.002;
    // console.log(-cpu_test.toFixed(4));
    for (var i = 0; i < my_rooms.length; i++) { // проход по румам
        starter_count[i] = 0,
        miner_count[i] = 0,
        upgrader_count[i] = 0,
        towner_count[i] = 0,
        scout_count[i] = 0,
        miner_count[i] = 0;
        helper_count[i] = 0;
        attacker_count[i] = 0;
        claimer_count[i] = 0;
        creep_alarm[i] = 0;
        // carryer_count[i] = 0,
        
        
        
        if (Game.rooms[my_rooms[i]].controller.level == 1) {
            miner_max = 0;
            carryer_max = 0;
        }
        my_controller[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTROLLER}})[0];
        
        containers_mass[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}});
        containers_no_sort[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}});
        
        containers_mass[i].sort((a,b) => a.store["energy"] - b.store["energy"]);
        // if (my_rooms[i] == "E32N44") {
        //     console.log("containers_no_sort:  0-", containers_no_sort[i][0].pos,containers_no_sort[i][0].store["energy"], "|  1-",containers_no_sort[i][1].pos, containers_no_sort[i][1].store["energy"]);
        //     console.log("containers_mass:     0-", containers_mass[i][0].pos,containers_mass[i][0].store["energy"], "|  1-",containers_mass[i][1].pos, containers_mass[i][1].store["energy"]);
        // }
        
        my_spawns[i] = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES, {filter: {structureType: STRUCTURE_SPAWN}});
        my_spawns[i].sort((a,b) => a.store[RESOURCE_ENERGY] - b.store[RESOURCE_ENERGY]);
        
        if (my_spawns[i].length > 1) {
            if (my_spawns[i][0].spawning) {
                spawner[i] = my_spawns[i][1];
            } else { spawner[i] = my_spawns[i][0]; }
        } else { spawner[i] = my_spawns[i][0]; }
        
        towers_mass[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_TOWER}});
        towers_mass[i].sort((a,b) => a.store[RESOURCE_ENERGY] - b.store[RESOURCE_ENERGY]);
        enemy[i] = towers_mass[i][0].pos.findClosestByRange(FIND_HOSTILE_CREEPS);
        if (towers_mass[i].length) {
            for (t = 0; t < towers_mass[i].length; ++t) {
                roleTower.run(towers_mass[i][t], enemy[i], t, towers_mass[i].length);
            }
        }
        
        extensions_mass[i] = Game.rooms[my_rooms[i]].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_EXTENSION}});
        extensions_mass[i].sort((a,b) => a.energy - b.energy);
        ext_count[i] = extensions_mass[i].length;
        
        
        if (ext_count[i] <= 4) {
            spawning_lvl[i] = 1;
        } else if (5 <= ext_count[i] && ext_count[i] <= 9) {
            spawning_lvl[i] = 2;
        } else if (10 <= ext_count[i] && ext_count[i] <= 19) {
            spawning_lvl[i] = 3;
        } else if (20 <= ext_count[i] && ext_count[i] <= 29) {
            spawning_lvl[i] = 4;
        } else if (30 <= ext_count[i] && ext_count[i] <= 49) {
            spawning_lvl[i] = 5;
        } else if (50 <= ext_count[i]) {
            spawning_lvl[i] = 6;
        }
        
        sources[i] = Game.rooms[my_rooms[i]].find(FIND_SOURCES);
        
        
        switch (spawning_lvl[i]) {
            case 1:
                starter_max[i] = 1,
                upgrader_max[i] = 2;
                break;
            case 2:
                starter_max[i] = 0,
                upgrader_max[i] = 2;
                helper_max[i] = 1;
                break;
            case 3:
                starter_max[i] = 0,
                upgrader_max[i] = 2;
                helper_max[i] = 1;
                break;
            case 4:
                starter_max[i] = 0,
                upgrader_max[i] = 2;
                helper_max[i] = 1;
                break;
        }      
        
        miner_max[i] = sources[i].length;
        if (my_rooms[i] == "E31N44") {
            attacker_max[i] = 0;
            upgrader_max[i] = 1;
            claimer_max[i] = 0;
            towner_max[i] = 0;
            carryer_max[i] = 0;
            helper_max[i] = 0;
            starter_max[i] = 1;
        }
        
        if (my_rooms[i] == "E32N44") {
            attacker_max[i] = 2;
            claimer_max[i] = 1;
            // scout_max[i] = 1;
            towner_max[i] = 2;
            if (spawning_lvl[i] < 4 && containers_mass[i][containers_mass.length - 1].store["energy"] > 1800) {
                if (spawning_lvl[i] == 2) {
                    upgrader_max[i] = 8;
                } else if (spawning_lvl[i] == 3) {
                    upgrader_max[i] = 6;
                }
            }
        }
        found_helper[i] = Game.rooms[my_rooms[i]].find(FIND_MY_CREEPS, {
            filter: (i) => i.memory.role == "Helper"
        })[0];
        if (found_helper[i]) {
            help_need[i] = 0
        } else {
            help_need[i] = 1
        }
        
        if (help_need[i] && Game.rooms[my_rooms[i]].energyAvailable < Game.rooms[my_rooms[i]].energyCapacityAvailable) {
            starter_max[i] = 1;
        }
        
        // if (my_rooms[i] == "E32N44") {
        //     console.log("starter_max=",starter_max[i]);
        // }
    }
    
    
    for (var name in Game.creeps) { // проход по крипам
        var creep = Game.creeps[name];
        const r = which_room(creep.memory.start_room);
        
        if (creep.memory.role == "Starter") {
            starter_count[r]++;
            roleStarter.run(creep, my_spawns[r], sources[r], extensions_mass[r], towers_mass[r], starter_max[r], my_controller[r]);
        } else if (creep.memory.role == "Miner") {
            miner_count[r]++;
            roleMiner.run(creep, my_spawns[r], sources[r]);
        } else if (creep.memory.role == "Upgrader") {
            upgrader_count[r]++;
            roleUpgrader.run(creep, my_spawns[r], sources[r], my_controller[r], containers_no_sort[r]);
        } else if (creep.memory.role == "Attacker") {
            attacker_count[r]++;
            roleAttacker.run(creep);
        } else if (creep.memory.role == "Claimer") {
            claimer_count[r]++;
            roleClaimer.run(creep);
        } else if (creep.memory.role == "Towner") {
            towner_count[r]++;
            roleTowner.run(creep);
        } else if (creep.memory.role == "Helper") {
            helper_count[r]++;
            roleHelper.run(creep, my_spawns[r], sources[r], extensions_mass[r], towers_mass[r], containers_mass[r]);
        } else if (creep.memory.role == "Scout") {
            scout_count[r]++;
            roleScout.run(creep);
        }
        
    }
    
    
     
    
    for (var i = 0; i < my_rooms.length; i++) { // 2-й проход по румам
        
        
        // if (my_rooms[i] == "E32N44") {
        //     if (spawning_lvl[i] < 4 && containers_mass[i][containers_mass.length - 1].store["energy"] > 1950) {
        //         upgrader_max[i] = 6;
        //     }
        // } // ломает 1 комнату?
        
        if (!spawner[i].spawning) {
            switch (spawning_lvl[i]) {
                case 1:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 300) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 2:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 550 || 
                       (Game.rooms[my_rooms[i]].energyAvailable >= 300 && starter_max[i] && !starter_count[i]) ) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 3:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 800 || 
                       (Game.rooms[my_rooms[i]].energyAvailable >= 300 && starter_max[i] && !starter_count[i]) ) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 4:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 1300 || 
                       (Game.rooms[my_rooms[i]].energyAvailable >= 300 && starter_max[i] && !starter_count[i]) ) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 5:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 1800 || 
                       (Game.rooms[my_rooms[i]].energyAvailable >= 300 && starter_max[i] && !starter_count[i]) ) {
                        spawn_start(spawner, i);
                    }
                    break;
                case 6:
                    if (Game.rooms[my_rooms[i]].energyAvailable >= 5000 || 
                       (Game.rooms[my_rooms[i]].energyAvailable >= 300 && starter_max[i] && !starter_count[i]) ) {
                        spawn_start(spawner, i);
                    }
                    break;
            }
        }
    
        if (my_controller[i].level <= 4) {
            for (var c = 0; c < containers_mass[i].length; c++) {
                let color_c,
                c_enrg = containers_mass[i][c].store["energy"]
                if (c_enrg > 1600) {
                    color_c = "red";
                } else if (c_enrg > 800) {
                    color_c = "yellow";
                } else {color_c = "green";}
                new RoomVisual(my_rooms[i]).text((containers_mass[i][c].store["energy"]+"🔅"), containers_mass[i][c].pos.x+1.3, 
                        containers_mass[i][c].pos.y+0.2, {color: color_c, font: 0.6, stroke: "black", strokeWidth: 0.1}); 
            }
        }
        
    }
    funcs.cpu_used();
    // console.log("-----------------------------------------------------------------------------------");
     
}