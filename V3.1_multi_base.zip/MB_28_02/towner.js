var funcs = require("funcs");

var roleTowner = {

    run: function(creep, my_spawns, sources, my_controller) {
        // --towner logic start--
        
        creep.say("🧱");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        if (creep.memory.start_room == "E31N44") {
            creep.memory.target_room = "E32N44";
        } else if (creep.memory.start_room == "E32N44") {
                creep.memory.target_room = "E32N48";
        }
        
        // console.log(creep.room.controller.reservation.username);
        if (creep.pos.roomName != creep.memory.target_room ) {
            creep.say("🥾🧱");
            funcs.scout_go(creep, creep.memory.target_room);
        } else if (creep.pos.roomName == creep.memory.target_room) {
            if (!creep.memory.full ) {
                var sources = creep.room.find(FIND_SOURCES),
                    target_source;
                if (sources[creep.name.split('Towner')[1]-1]) {
                    target_source = sources[creep.name.split('Towner')[1]-1];
                } else {
                    target_source = sources[0];
                }
                
                if (creep.harvest(target_source) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(target_source);
                }
            } else if (creep.memory.full) {
                var construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                if (construction) {
                    if(creep.build(construction) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(construction);
                    }
                } else {
                    if (!creep.pos.isNearTo(25,25)) {
                        creep.moveTo(25,25);
                    }
                }
                
            }
            
        }
        
        // if (!creep.memory.full) {
        //     const my_container = creep.pos.findClosestByRange(FIND_STRUCTURES, {
        //         filter: (i) => i.structureType == STRUCTURE_CONTAINER
        //     });
        //     if (my_container) {
        //         if (my_container.store["energy"] > 300) {
        //             if(creep.withdraw(my_container, "energy") == ERR_NOT_IN_RANGE) {
        //                 if (!creep.pos.isNearTo(my_container)) {
        //                     creep.moveTo(my_container);
        //                 } 
        //             }
        //         }
        //     } else if (creep.harvest(sources[0]) == ERR_NOT_IN_RANGE) {
        //         creep.moveTo(sources[0]);
        //     }
        // } else if (creep.memory.full) {
            
        //     if (Game.time % 6 == 0) {
        //         construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
        //         if (construction) {
        //             creep.memory.building = 1;
        //         } else { creep.memory.building = 0; }
        //     }
        //     // console.log(my_controller);
            
        //     if (creep.memory.building) {
        //         // console.log(construction.pos);
        //         if(creep.build(construction) == ERR_NOT_IN_RANGE) {
        //             creep.moveTo(construction);
        //         }
        //     } else if (my_controller.level < 8 || my_controller.ticksToDowngrade < 190000) {
        //         if (creep.upgradeController(my_controller) == ERR_NOT_IN_RANGE) {
        //             creep.moveTo(my_controller);
        //         }
        //     }
        // }
        // --towner logic end--
        
    }
};

module.exports = roleTowner;