
var rolePSpawn = {

    run: function(my_pSpawn, my_storage, my_terminal) {
        // --PSpawn logic start--
        
      if (my_storage && my_terminal && my_pSpawn) {
          if (my_pSpawn.store['power'] > 0 && my_pSpawn.store['energy'] >= 50) {
              my_pSpawn.processPower();
          }
      }
        
        
        
         // --PSpawn logic end--
    } 
}

module.exports = rolePSpawn;