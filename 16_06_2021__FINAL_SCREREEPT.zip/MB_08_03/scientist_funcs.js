module.exports.produce_compound = function produce_compound(creep, component0, component1, compound, ammount, my_storage, my_terminal, my_factory, inputLabs, labs) {
    var found_compound = false;
    for (lab of labs) {
        if (lab.store[compound] > 0) { found_compound = true }
    }
    if ( (inputLabs[0].store[component0] < ammount || inputLabs[1].store[component1] < ammount) && !found_compound && creep.store[compound] == 0 ) {
            if (inputLabs[0].store[component0] < ammount) {
                this.bring_ammount(creep, component0, ammount, my_terminal, inputLabs[0])
            } else if (inputLabs[1].store[component1] < ammount) {
                this.bring_ammount(creep, component1, ammount, my_terminal, inputLabs[1])
            }
    } else if (inputLabs[0].store[component0] > 0 && inputLabs[1].store[component1] > 0 ){
        creep.say("⚗️");
        for (lab of labs) {
            if (lab.cooldown == 0 && lab != inputLabs[0] && lab != inputLabs[1]) {
                lab.runReaction(inputLabs[0], inputLabs[1]);
            }
        }
    } else {
        
        var target_lab = 0;
        for (lab of labs) {
            if (lab.store[compound] > 0) {
                target_lab = lab;
            }
        }
        if (target_lab || creep.store[compound] > 0) {
            if (creep.ticksToLive > 20) {
                if (target_lab && creep.store.getFreeCapacity() > 0) {
                    if(creep.withdraw(target_lab, compound) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(target_lab);
                    }
                } else if (creep.store[compound] > 0) {
                    if(creep.transfer(my_terminal, compound) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(my_terminal);
                    }
                }
            }
        }
    }
}


module.exports.move_batteries = function move_batteries(creep, my_terminal, my_factory, battery_reserve) {
    creep.say("🔬🔋");
    if (my_terminal.store['battery'] < battery_reserve && (my_factory.store['battery'] >= 200  || creep.store["battery"] > 0)  ) {
        var ammount = battery_reserve;
        // console.log(ammount, creep)
        this.bring_ammount(creep, 'battery', ammount, my_factory, my_terminal)
    }
}

module.exports.bring_ammount = function bring_ammount(creep, component, ammount, from, to) {
    var still_needed = ammount - to.store[component],
        now_take;
        
    if (still_needed > creep.store.getCapacity()) {
        now_take = creep.store.getCapacity();
    } else {
        now_take = still_needed;
    }    
    
    if (creep.store.getFreeCapacity() == 0  || creep.store[component] == now_take) {
        creep.memory.full = true;
    } else if (creep.store.getFreeCapacity() == creep.store.getCapacity()) {
        creep.memory.full = false;
    }
    
    if (!creep.memory.full) {
        creep.say("🧪📥");
        if (creep.ticksToLive > 20) {
            if(creep.withdraw(from, component, now_take) == ERR_NOT_IN_RANGE) {
                creep.moveTo(from);
            }
        }
    } else if (creep.memory.full) {
        creep.say("🧪📤");
        if(creep.transfer(to, component) == ERR_NOT_IN_RANGE) {
            creep.moveTo(to);
        }
    }
}

module.exports.move_power = function move_batteries(creep, my_terminal, my_pSpawn) {
    creep.say("🔬🔴");
    this.bring_ammount(creep, 'power', 100, my_terminal, my_pSpawn)
}

module.exports.clean_all = function clean_all(creep, labs, my_terminal) {
    if (Object.keys(creep.store)[0]) {
        if(creep.transfer(my_terminal, Object.keys(creep.store)[0]) == ERR_NOT_IN_RANGE) {
            creep.moveTo(my_terminal);
        }
    } else {
        for (lab of labs) {
            if (lab.mineralType) {
                if(creep.withdraw(lab, lab.mineralType) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(lab);
                }
                break;
            }
        }
    }
    
}



