var laborant_x, laborant_y;
//баг - если берет энергию при ticks to live = 1, то просто умирает
var roleLaborant = {

    run: function(creep, my_storage, link_to, my_terminal, my_factory, my_nuker, my_pSpawn) {
        // --laborant logic start--
        creep.say("🔗");
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity() || creep.ticksToLive < 12) {
            creep.memory.full = true;
        }
        
        laborant_x = (my_storage.pos.x + link_to.pos.x)/2;
        laborant_y = (my_storage.pos.y + link_to.pos.y)/2;
        
        
        if (!creep.memory.full) {
            if(!creep.pos.isEqualTo(laborant_x,laborant_y)) {
                creep.moveTo(laborant_x,laborant_y);
            } else {
                if (link_to.store["energy"] > 0) {
                    creep.withdraw(link_to, "energy");
                }
            }
            
        } else if (creep.memory.full) {
            if (my_storage && my_storage.store["energy"] < 50000) {
                if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_storage)) {
                        creep.moveTo(my_storage);
                    }
                }
            } else if (my_terminal && my_terminal.store["energy"] < 20000) {
                if(creep.transfer(my_terminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_terminal)) {
                        creep.moveTo(my_terminal);
                    }
                }
            } else if (my_storage && my_storage.store["energy"] < 100000) {
                if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_storage)) {
                        creep.moveTo(my_storage);
                    }
                }
            } else if (my_nuker && my_nuker.store["energy"] < 300000) {
                if(creep.transfer(my_nuker, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_nuker)) {
                        creep.moveTo(my_nuker);
                    }
                }
            } else if (my_pSpawn && my_pSpawn.store["energy"] < 4000) {
                if(creep.transfer(my_pSpawn, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_pSpawn)) {
                        creep.moveTo(my_pSpawn);
                    }
                }
            } else if (my_terminal && my_terminal.store["energy"] < 100000) {
                if(creep.transfer(my_terminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_terminal)) {
                        creep.moveTo(my_terminal);
                    }
                }
            } else if (my_storage && my_storage.store["energy"] < 500000) {
                if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_storage)) {
                        creep.moveTo(my_storage);
                    }
                }
            } else if (my_factory && my_factory.store["energy"] < 5000 && my_factory.store["battery"] < 5000) {
                if(creep.transfer(my_factory, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(my_factory)) {
                        creep.moveTo(my_factory);
                    }
                }
            } 
        } 
    } 
         
        // --laborant logic end--
        
}

module.exports = roleLaborant;